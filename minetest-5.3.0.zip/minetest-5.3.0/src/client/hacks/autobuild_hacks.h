#include <iostream>
#include <fstream>

using namespace std;

bool u() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/autobuild", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

bool v() {
	if (u() == 1) {
		return true;
	}
	else
	{
		bool a = false;
		return a;
	}
}

#include <iostream>
#include <fstream>

using namespace std;

bool g() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/autoclick", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

bool h() {
	if (g() == 1) {
		return true;
	}
	else
	{
		bool a = false;
		return a;
	}
}

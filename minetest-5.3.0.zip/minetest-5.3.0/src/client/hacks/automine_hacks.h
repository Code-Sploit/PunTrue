#include <iostream>
#include <fstream>
#include <string>

using namespace std;

bool e() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/automine", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

float f() {
	if (e() == 1) {
		float a = 0.00000000001;
		return a;
	}
	else
	{
		float a = 1.0;
		return a;
	}
}

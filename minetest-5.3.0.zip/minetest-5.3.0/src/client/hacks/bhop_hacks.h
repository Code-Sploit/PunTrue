#include <string>
#include <iostream>
#include <fstream>

using namespace std;

bool m() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/bhop", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

float n() {
	if (m() == 1) {
		float a = 4.0;
		return a;
	}
	else
	{
		float a = 1.0;
		return a;
	}
}

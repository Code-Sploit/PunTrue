#include <string>
#include <iostream>
#include <fstream>

using namespace std;

bool aa() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/dcs", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

float bb() {
	if (aa() == 1) {
		float a = 100000.0;
		return a;
	}
	else
	{
		float a = 0.0;
		return a;
	}
}

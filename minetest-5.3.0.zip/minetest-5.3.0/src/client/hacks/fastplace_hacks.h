#include <string>
#include <iostream>
#include <fstream>

using namespace std;

bool s() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/fastplace", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

float t() {
	if (s() == 1) {
		float a = 0.2;
		return a;
	}
	else
	{
		float a = 0.25;
		return a;
	}
}

#include <string>
#include <iostream>
#include <fstream>

using namespace std;

bool y() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/high_eye", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

float z() {
	if (y() == 1) {
		float a = 2.0;
		return a;
	}
	else
	{
		float a = 0.0;
		return a;
	}
}

#include <string>
#include <iostream>
#include <fstream>

using namespace std;

bool a() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/killaura", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

float b() {
	if (a() == 1) {
		float a = 0.00000000000000000000000000000001;
		return a;
	}
	else
	{
		float a = 0.2;
		return a;
	}
}

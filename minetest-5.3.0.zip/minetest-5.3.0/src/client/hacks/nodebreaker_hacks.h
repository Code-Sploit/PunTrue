#include <string>
#include <iostream>
#include <fstream>

using namespace std;

bool i() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/nodebreaker", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

float j() {
	if (i() == 1) {
		float a = 1.0;
		return a;
	}
	else
	{
		float a = 1000000.0;
		return a;
	}
}

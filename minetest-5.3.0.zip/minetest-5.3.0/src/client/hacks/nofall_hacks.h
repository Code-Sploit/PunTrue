#include <iostream>
#include <fstream>

using namespace std;

bool k() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/nofall", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

bool l() {
	if (k() == 1) {
		bool a = false;
		return a;
	}
	else
	{
		bool a = true;
		return a;
	}
}

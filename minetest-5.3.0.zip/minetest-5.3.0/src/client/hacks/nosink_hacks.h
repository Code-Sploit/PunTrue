#include <string>
#include <iostream>
#include <fstream>

using namespace std;

bool o() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/nosink", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

float p() {
	if (o() == 1) {
		float a = 0.0;
		return a;
	}
	else
	{
		float a = 1.0;
		return a;
	}
}

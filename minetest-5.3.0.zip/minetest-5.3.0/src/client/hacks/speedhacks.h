#include <string>
#include <iostream>
#include <fstream>

using namespace std;

bool c() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/speed", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

float d() {
	if (c() == 1) {
		float a = 2.0;
		return a;
	}
	else
	{
		float a = 1.0;
		return a;
	}
}

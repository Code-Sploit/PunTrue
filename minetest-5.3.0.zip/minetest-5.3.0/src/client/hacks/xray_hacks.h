#include <iostream>
#include <fstream>

using namespace std;

bool q() {
	fstream cfile;
	cfile.open("/home/skyfight/.minetest/hacks/xray", ios::in);

	if (cfile.is_open()) {
		return true;
	}
	else
	{
		return false;
	}
}

bool r() {
	if (q() == 1) {
		bool a = true;
		return a;
	}
	else
	{
		bool a = false;
		return a;
	}
}

// Filled in by the build system
// Separated from cmake_config.h to avoid excessive rebuilds on every commit

#pragma once

#define VERSION_GITHASH "5.3.0"

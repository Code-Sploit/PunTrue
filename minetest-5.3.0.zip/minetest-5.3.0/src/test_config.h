// Filled in by the build system

#pragma once

#define TEST_WORLDDIR "/home/skyfight/hacked/minetest-5.3.0/src/unittest/test_world"
#define TEST_SUBGAME_PATH "/home/skyfight/hacked/minetest-5.3.0/src/unittest/../../games/devtest"
